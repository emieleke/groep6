﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Rekenmachine_goeie
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        string input = string.Empty;
        string Optie1 = string.Empty;
        string Optie2 = string.Empty;
        char operation;
        double result = 0.0;

        private void Plus(object sender, RoutedEventArgs e)
        {
            Optie1 = input;
            operation = '+';
            input = string.Empty;
        }

        private void Minus(object sender, RoutedEventArgs e)
        {
            Optie1 = input;
            operation = '-';
            input = string.Empty;
        }

        private void Keer(object sender, RoutedEventArgs e)
        {
            Optie1 = input;
            operation = '*';
            input = string.Empty;
        }

        private void Delen(object sender, RoutedEventArgs e)
        {
            Optie1 = input;
            operation = '/';
            input = string.Empty;
        }

        private void Dollar(object sender, RoutedEventArgs e)
        {
            Optie1 = input;
            operation = '$';
            input = string.Empty;
        }

        private void One(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "1";
            this.Result.Text += input;
        }

        private void two(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "2";
            this.Result.Text += input;
        }

        private void three(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "3";
            this.Result.Text += input;
        }

        private void four(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "4";
            this.Result.Text += input;
        }

        private void Five(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "5";
            this.Result.Text += input;
        }

        private void Six(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "6";
            this.Result.Text += input;
        }

        private void Seven(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "7";
            this.Result.Text += input;
        }

        private void Aight(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "8";
            this.Result.Text += input;
        }

        private void Nine(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "9";
            this.Result.Text += input;
        }

        private void Zero(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            input += "0";
            this.Result.Text += input;
        }

        private void Clear(object sender, RoutedEventArgs e)
        {
            this.Result.Text = "";
            this.input = string.Empty;
            this.Optie1 = string.Empty;
            this.Optie2 = string.Empty;
        }

        private void Result_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Boktor(object sender, RoutedEventArgs e)
        {
            Optie2 = input;
            double num1, num2;
            double.TryParse(Optie1, out num1);
            double.TryParse(Optie2, out num2);

            if (operation == '+')
            {
                result = num1 + num2;
                

            }
            else if (operation == '-')
            {
                result = num1 - num2;
               
            }
            else if (operation == '*')
            {
                result = num1 * num2;
                
            }
            else if (operation == '/')
            {
                result = num1 / num2;
                
            }
            else if (operation == '$')
            {
                result = num1 / 100 * 110;
                
            }
            else if (operation == '%')
            {
                result = num1 % num2;
               
            }
            Result.Text = result.ToString();



        }

        private void Binair(object sender, RoutedEventArgs e)
        {


            if (input != "")
            {
                double invoerBiniar = Convert.ToDouble(input);
                long binair = BitConverter.DoubleToInt64Bits(invoerBiniar);
                string str = Convert.ToString(binair, 2);
                Result.Text = str;

            }
            else
            {
                Result.Text = "Voer iets in";
            }


        }

        private void Komma(object sender, RoutedEventArgs e)
        {
            this.Result.Text = " ";
            input += ",";
            this.Result.Text += input;
        }

        private void Negatief(object sender, RoutedEventArgs e)
        {
            if (Result.Text.Contains("-"))

            {



                Result.Text = Result.Text.Remove(0, 1);

            }

            else

            {

                Result.Text = "-" + Result.Text;

            }



        }

        private void Modulo(object sender, RoutedEventArgs e)
        {
            Optie1 = input;
            operation = '%';
            input = string.Empty;
        }
    }

}